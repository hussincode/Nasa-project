// server.js
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const FormData = require('form-data');
const axios = require('axios');
const fs = require('fs');
const https = require('https');

const app = express();
const upload = multer({ dest: 'uploads/' });

// Enable CORS for React frontend
app.use(cors());
app.use(express.json());

// Your friend's AI API URL
const AI_API_URL = 'https://127.0.0.1:8000/predict';

// Create uploads folder if it doesn't exist
if (!fs.existsSync('uploads')) {
    fs.mkdirSync('uploads');
}

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({
        status: 'healthy',
        service: 'Express Backend',
        port: 5000,
        aiApiUrl: AI_API_URL
    });
});

// CSV upload endpoint - forwards to AI API
app.post('/upload-csv', upload.single('file'), async (req, res) => {
    console.log('\n' + '='.repeat(60));
    console.log('Received CSV upload from frontend');
    
    if (!req.file) {
        console.log('✗ No file in request');
        console.log('='.repeat(60) + '\n');
        return res.status(400).json({ error: 'No file uploaded' });
    }

    console.log(`✓ File: ${req.file.originalname}`);
    console.log(`✓ Size: ${req.file.size} bytes`);

    try {
        // Create form data to send to AI API
        const formData = new FormData();
        formData.append('file', fs.createReadStream(req.file.path), {
            filename: req.file.originalname,
            contentType: 'text/csv'
        });

        console.log(`Forwarding CSV to AI API: ${AI_API_URL}`);

        // Create HTTPS agent that ignores SSL certificate errors (for local development)
        const httpsAgent = new https.Agent({
            rejectUnauthorized: false // Only use this for development with self-signed certificates
        });

        // Send CSV to your friend's AI API
        const response = await axios.post(AI_API_URL, formData, {
            headers: {
                ...formData.getHeaders()
            },
            httpsAgent: httpsAgent, // Use for HTTPS with self-signed cert
            timeout: 120000, // 2 minute timeout
            maxContentLength: Infinity,
            maxBodyLength: Infinity
        });

        console.log('✓ AI API responded successfully');
        console.log(`✓ Response status: ${response.status}`);

        // Clean up uploaded file
        fs.unlinkSync(req.file.path);
        console.log('✓ Temporary file cleaned up');
        console.log('='.repeat(60) + '\n');

        // Forward AI API response to React frontend
        res.json({
            success: true,
            data: response.data,
            filename: req.file.originalname
        });

    } catch (error) {
        console.log('✗ Error occurred:');
        
        // Clean up on error
        if (req.file && fs.existsSync(req.file.path)) {
            fs.unlinkSync(req.file.path);
            console.log('✓ Temporary file cleaned up');
        }
        
        if (error.code === 'ECONNREFUSED') {
            console.log('✗ Cannot connect to AI API at ' + AI_API_URL);
            console.log('  Make sure your friend\'s AI service is running');
            console.log('='.repeat(60) + '\n');
            return res.status(503).json({ 
                error: 'AI service is not reachable',
                details: 'Cannot connect to ' + AI_API_URL
            });
        }

        if (error.code === 'ENOTFOUND') {
            console.log('✗ Invalid AI API URL');
            console.log('='.repeat(60) + '\n');
            return res.status(503).json({ 
                error: 'Invalid AI service URL',
                details: 'Check the AI_API_URL configuration'
            });
        }

        if (error.response) {
            console.log(`✗ AI API error: ${error.response.status}`);
            console.log(`✗ AI API message: ${JSON.stringify(error.response.data)}`);
            console.log('='.repeat(60) + '\n');
            return res.status(error.response.status).json({
                error: 'AI service returned an error',
                details: error.response.data
            });
        }
        
        console.log(`✗ ${error.message}`);
        console.log('='.repeat(60) + '\n');
        
        res.status(500).json({ 
            error: 'Failed to process file',
            details: error.message
        });
    }
});

const PORT = 5000;
app.listen(PORT, () => {
    console.log('\n' + '='.repeat(60));
    console.log('Express Backend Server Started');
    console.log('='.repeat(60));
    console.log(`Server: http://localhost:${PORT}`);
    console.log(`Upload endpoint: http://localhost:${PORT}/upload-csv`);
    console.log(`Health check: http://localhost:${PORT}/health`);
    console.log(`AI API: ${AI_API_URL}`);
    console.log('='.repeat(60));
    console.log('How it works:');
    console.log('   React → Express → AI API → Express → React');
    console.log('='.repeat(60) + '\n');
});