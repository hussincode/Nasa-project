import React, { useState } from 'react';

export default function SpiralGalaxy() {
  const [file, setFile] = useState(null);
  const [csvData, setCsvData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [predictions, setPredictions] = useState(null);

  const handleFileChange = async (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile && selectedFile.type === 'text/csv') {
      setFile(selectedFile);
      setError(null);
      await uploadToBackend(selectedFile);
    } else {
      setError('Please select a valid CSV file');
    }
  };

  const uploadToBackend = async (file) => {
    setLoading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      // Send to Express backend
      const response = await fetch('http://localhost:5000/upload-csv', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Upload failed');
      }

      const result = await response.json();
      setCsvData(result);
      setPredictions(result.data);
      console.log('Backend Response:', result);
    } catch (err) {
      setError(err.message || 'Failed to upload file');
      console.error('Upload error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.container}>
      {/* Static Stars Layer 1 - Small stars */}
      <div style={styles.starsLayer}>
        {[...Array(100)].map((_, i) => (
          <div
            key={`star1-${i}`}
            style={{
              ...styles.star,
              width: Math.random() * 2 + 0.5 + 'px',
              height: Math.random() * 2 + 0.5 + 'px',
              left: Math.random() * 100 + '%',
              top: Math.random() * 100 + '%',
              opacity: Math.random() * 0.5 + 0.3,
              animationDelay: Math.random() * 3 + 's',
              animationDuration: Math.random() * 3 + 2 + 's'
            }}
          />
        ))}
      </div>

      {/* Static Stars Layer 2 - Medium stars */}
      <div style={styles.starsLayer}>
        {[...Array(50)].map((_, i) => (
          <div
            key={`star2-${i}`}
            style={{
              ...styles.star,
              ...styles.starMedium,
              width: Math.random() * 3 + 1 + 'px',
              height: Math.random() * 3 + 1 + 'px',
              left: Math.random() * 100 + '%',
              top: Math.random() * 100 + '%',
              opacity: Math.random() * 0.7 + 0.3,
              animationDelay: Math.random() * 4 + 's',
              animationDuration: Math.random() * 4 + 2 + 's'
            }}
          />
        ))}
      </div>

      {/* Nebula Clouds */}
      <div style={styles.nebulaContainer}>
        <div style={{...styles.nebula, ...styles.nebula1}} />
        <div style={{...styles.nebula, ...styles.nebula2}} />
        <div style={{...styles.nebula, ...styles.nebula3}} />
        <div style={{...styles.nebula, ...styles.nebula4}} />
        <div style={{...styles.nebula, ...styles.nebula5}} />
      </div>

      {/* Shooting Stars */}
      <div style={styles.shootingStarsContainer}>
        {[...Array(5)].map((_, i) => (
          <div
            key={`shooting-${i}`}
            style={{
              ...styles.shootingStar,
              left: Math.random() * 100 + '%',
              top: Math.random() * 50 + '%',
              animationDuration: Math.random() * 3 + 2 + 's',
              animationDelay: Math.random() * 10 + 's'
            }}
          />
        ))}
      </div>

      {/* CSV Upload Section */}
      <div style={styles.uploadContainer}>
        <div style={styles.uploadCard}>
          <h2 style={styles.uploadTitle}>Upload CSV File</h2>
          
          <label style={styles.fileInputLabel}>
            <input
              type="file"
              accept=".csv"
              onChange={handleFileChange}
              style={styles.fileInput}
              disabled={loading}
            />
            <div style={{...styles.uploadButton, ...(loading ? styles.uploadButtonDisabled : {})}}>
              <svg style={styles.uploadIcon} viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
              </svg>
              <span>{loading ? 'Uploading...' : file ? file.name : 'Choose CSV File'}</span>
            </div>
          </label>

          {error && (
            <div style={styles.errorInfo}>
              <p style={styles.errorText}>✗ {error}</p>
            </div>
          )}

          {csvData && !loading && (
            <div style={styles.fileInfo}>
              <p style={styles.successText}>✓ File uploaded successfully!</p>
              <p style={styles.infoText}>Filename: {csvData.filename}</p>
              {predictions && (
                <div style={styles.predictionsSection}>
                  <h3 style={styles.predictionsTitle}>AI Response:</h3>
                  <pre style={styles.predictionsData}>{JSON.stringify(predictions, null, 2)}</pre>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }

        @keyframes float {
          0%, 100% {
            transform: translate(0, 0) scale(1);
          }
          33% {
            transform: translate(30px, -30px) scale(1.1);
          }
          66% {
            transform: translate(-20px, 20px) scale(0.9);
          }
        }

        @keyframes shooting {
          0% {
            transform: translateX(0) translateY(0);
            opacity: 1;
          }
          70% {
            opacity: 1;
          }
          100% {
            transform: translateX(300px) translateY(300px);
            opacity: 0;
          }
        }
      `}</style>
    </div>
  );
}

const styles = {
  container: {
    position: 'relative',
    width: '100%',
    minHeight: '100vh',
    backgroundColor: '#000000',
    overflow: 'hidden'
  },
  starsLayer: {
    position: 'absolute',
    inset: 0,
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  },
  star: {
    position: 'absolute',
    backgroundColor: '#ffffff',
    borderRadius: '50%',
    animation: 'pulse infinite'
  },
  starMedium: {
    boxShadow: '0 0 4px rgba(255, 255, 255, 0.8)'
  },
  nebulaContainer: {
    position: 'absolute',
    inset: 0,
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  },
  nebula: {
    position: 'absolute',
    borderRadius: '50%',
    filter: 'blur(80px)',
    animation: 'float ease-in-out infinite'
  },
  nebula1: {
    width: '384px',
    height: '384px',
    background: 'radial-gradient(circle, rgba(138, 43, 226, 0.4) 0%, transparent 70%)',
    left: '10%',
    top: '20%',
    opacity: 0.3,
    animationDuration: '20s'
  },
  nebula2: {
    width: '500px',
    height: '500px',
    background: 'radial-gradient(circle, rgba(255, 20, 147, 0.3) 0%, transparent 70%)',
    right: '15%',
    top: '10%',
    opacity: 0.25,
    animationDuration: '25s',
    animationDirection: 'reverse'
  },
  nebula3: {
    width: '320px',
    height: '320px',
    background: 'radial-gradient(circle, rgba(147, 51, 234, 0.4) 0%, transparent 70%)',
    left: '50%',
    top: '50%',
    opacity: 0.2,
    animationDuration: '30s'
  },
  nebula4: {
    width: '384px',
    height: '384px',
    background: 'radial-gradient(circle, rgba(59, 130, 246, 0.3) 0%, transparent 70%)',
    right: '10%',
    bottom: '20%',
    opacity: 0.25,
    animationDuration: '22s',
    animationDirection: 'reverse'
  },
  nebula5: {
    width: '288px',
    height: '288px',
    background: 'radial-gradient(circle, rgba(236, 72, 153, 0.3) 0%, transparent 70%)',
    left: '30%',
    bottom: '15%',
    opacity: 0.2,
    animationDuration: '28s'
  },
  shootingStarsContainer: {
    position: 'absolute',
    inset: 0,
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  },
  shootingStar: {
    position: 'absolute',
    width: '4px',
    height: '4px',
    backgroundColor: '#ffffff',
    borderRadius: '50%',
    animation: 'shooting linear infinite',
    boxShadow: '0 0 2px 2px rgba(255, 255, 255, 0.3), 0 0 10px rgba(255, 255, 255, 0.2)'
  },
  uploadContainer: {
    position: 'relative',
    zIndex: 10,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: '100vh',
    padding: '20px'
  },
  uploadCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    backdropFilter: 'blur(10px)',
    border: '1px solid rgba(255, 255, 255, 0.1)',
    borderRadius: '20px',
    padding: '40px',
    maxWidth: '500px',
    width: '100%',
    boxShadow: '0 8px 32px rgba(0, 0, 0, 0.3)'
  },
  uploadTitle: {
    color: '#ffffff',
    fontSize: '28px',
    fontWeight: 'bold',
    marginBottom: '30px',
    textAlign: 'center',
    background: 'linear-gradient(to right, #a855f7, #ec4899)',
    WebkitBackgroundClip: 'text',
    WebkitTextFillColor: 'transparent',
    backgroundClip: 'text'
  },
  fileInputLabel: {
    display: 'block',
    cursor: 'pointer'
  },
  fileInput: {
    display: 'none'
  },
  uploadButton: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '40px 20px',
    border: '2px dashed rgba(168, 85, 247, 0.5)',
    borderRadius: '12px',
    backgroundColor: 'rgba(168, 85, 247, 0.1)',
    transition: 'all 0.3s ease',
    color: '#ffffff'
  },
  uploadButtonDisabled: {
    opacity: 0.5,
    cursor: 'not-allowed'
  },
  uploadIcon: {
    width: '48px',
    height: '48px',
    marginBottom: '12px',
    color: '#a855f7'
  },
  fileInfo: {
    marginTop: '20px',
    padding: '20px',
    backgroundColor: 'rgba(34, 197, 94, 0.1)',
    border: '1px solid rgba(34, 197, 94, 0.3)',
    borderRadius: '12px'
  },
  successText: {
    color: '#4ade80',
    fontSize: '16px',
    fontWeight: 'bold',
    margin: '0 0 10px 0'
  },
  infoText: {
    color: '#ffffff',
    fontSize: '14px',
    margin: '5px 0'
  },
  errorInfo: {
    marginTop: '20px',
    padding: '20px',
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    border: '1px solid rgba(239, 68, 68, 0.3)',
    borderRadius: '12px'
  },
  errorText: {
    color: '#ef4444',
    fontSize: '16px',
    fontWeight: 'bold',
    margin: '0'
  },
  predictionsSection: {
    marginTop: '20px',
    padding: '15px',
    backgroundColor: 'rgba(168, 85, 247, 0.1)',
    border: '1px solid rgba(168, 85, 247, 0.3)',
    borderRadius: '8px'
  },
  predictionsTitle: {
    color: '#a855f7',
    fontSize: '16px',
    fontWeight: 'bold',
    margin: '0 0 10px 0'
  },
  predictionsData: {
    color: '#ffffff',
    fontSize: '12px',
    margin: 0,
    whiteSpace: 'pre-wrap',
    wordWrap: 'break-word',
    maxHeight: '300px',
    overflow: 'auto'
  }
};